# Revision 3 changes

The manuscript's central claims were calibrated to finite candidate pools and
tested scenarios. No global internalization threshold, universal mechanism
ranking, length necessity, or uniquely isolated idle channel is asserted.

Main paired statistics now use unrounded re-evaluated chromosomes. Representative
points, paired run summaries, population SD and sample-based t intervals are
explicitly distinguished. Main representative points and multiset coverage retain
their original protocol.

The common pool was RECONSTRUCTED from the public E3 four-price fronts and BASE
candidates within matched runs. This is a different, fully archived pool from the
previous summary-only new-seed experiment, so Table 5 and Figure 5 were updated.

Seven figures were regenerated. Figure 2 names queue-append earliest-start
decoding, Figure 7 names the joint idle/startup parameter, and Figure 5 reports
sampled mean +/- SD without interpolation of an unknown threshold.

Historical E6 signed fields and example import/output setup were corrected in
this local supplement. Original summaries are kept under legacy_summary. The
data and parameter provenance now distinguish illustrative assumptions from
industrial-source reproduction parameters. The public GitHub repository was not
modified by this local revision.
